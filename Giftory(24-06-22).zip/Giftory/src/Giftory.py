from flask import *
import os
from werkzeug.utils import secure_filename

from src.dbconnection import *
app=Flask(__name__)
app.secret_key="aaaaaaa"

@app.route('/')
def login():
    return render_template("login.html")

#############login#################
@app.route('/logincode',methods=['post'])
def logincode():
    print(request.form)

    uname=request.form["textfield"]
    psw=request.form["textfield2"]

    qry = "select * from vendor where username=%s and password=%s"
    val = (uname, psw)
    res = selectone(qry,val)


    if res is None:
        return '''<script>
                alert("Invalid username or password");
                window.location='/';
                </script>'''

    elif res[13]=="admin":
        session['lid']=res[0]
        return  '''<script>alert("Login sucessfull"); window.location='/homepage'; </script>'''
    elif res[13]=="craft":
        session['lid'] = res[0]
        return '''<script>
                alert("Login sucessfull"); window.location='/craft_homepage';
                </script>'''
    elif res[13]=="blocked":
        session['lid'] = res[0]
        return '''<script>
                alert("You are blocked by the admin.Please contact admin");
                window.location='/';
                </script>'''
    elif res[13]=="pending":
        return '''<script>
                alert("You are under verfication please wait for verified");
                window.location='/';
                </script>'''
    else:

        return '''<script>
        alert("Invalid username or password");
        window.location='/';
        </script>'''

###############admin###############
@app.route('/homepage')
def hompage():
    return render_template("admin/admin_home.html")

@app.route('/admin_addproduct')
def admin_addproduct():
    return render_template("admin/admin_add_product.html")
@app.route('/admin_edit_product')
def admin_edit_product():
    p_id=request.args.get('id')
    session['pid']=p_id
    qry="select * from product where p_id=%s"
    res=selectone(qry,p_id)
    print(res)
    return render_template("admin/admin_edit_product.html",val=res)

@app.route('/add_product',methods=['post'])
def add_product():
    p_name=request.form['textfield']
    catogery=request.form['select']
    occasion=request.form['select2']
    description=request.form['textarea']
    type=request.form['radiobutton']
    img=request.files['file']
    price=request.form['textfield3']
    qty=request.form['textfield4']
    v_id=session['lid']
    fname = secure_filename(img.filename)
    img.save(os.path.join('static/product', fname))
    qry="insert into product value(NULL ,%s,%s,%s,%s,%s,%s,%s,0,%s,%s)"
    val=(p_name,fname,catogery,occasion,description,qty,price,type,str(v_id))
    iud(qry,val)
    return '''<script> 
        alert("Added sucessful"),
        window.location='/admin_view_product';
        </script>'''


@app.route('/edit_product_code',methods=['post'])
def edit_product_code():
    try:
        p_name=request.form['textfield']
        catogery=request.form['select']
        occasion=request.form['select2']
        description=request.form['textarea']
        type=request.form['radiobutton']
        img=request.files['file']
        price=request.form['textfield3']
        qty=request.form['textfield4']
        v_id=session['lid']
        fname = secure_filename(img.filename)
        img.save(os.path.join('static/product', fname))
        qry="update product set p_name=%s ,fname=%s, category=%s, description=%s ,quantity=%s , price=%s, type=%s where p_id=%s"
        val=(p_name,fname,catogery,occasion,description,qty,price,type,session['pid'])
        iud(qry,val)
        return '''<script> 
            alert("Update sucessful"),
            window.location=''admin_view_product;
            </script>'''
    except Exception:

        p_name = request.form['textfield']
        catogery = request.form['select']
        occasion = request.form['select2']
        description = request.form['textarea']
        type = request.form['radiobutton']
        price = request.form['textfield3']
        qty = request.form['textfield4']


        qry = "update product set p_name=%s ,occasion=%s, category=%s, description=%s, quantity=%s , price=%s ,type=%s where p_id=%s"
        val = (p_name, catogery, occasion, description, qty, price, type, session['pid'])
        iud(qry, val)
        return '''<script> 
                   alert("Update sucessful"),
                   window.location='/admin_view_product';
                   </script>'''



@app.route('/admin_unblock')
def admin_unblock():
    qry="select * from vendor where status='blocked'"
    res=selectall(qry)
    return render_template("admin/unblock_craft.html",val=res)


@app.route('/product_delete')
def product_delete():
    id=request.args.get('id')
    qry="delete from product where p_id=%s"
    iud(qry,id)
    return '''<script>
    alert("Product deleted sucessful"),
    window.location="/admin_view_product";
    </script>'''

@app.route('/admin_adddiscount')
def admin_adddiscount():
    return render_template("admin/admin_add_discount.html")

@app.route('/approve_craft')
def approve_craft():
    qry= " select * from vendor where status='pending' "
    res=selectall(qry)
    return render_template("admin/admin_approve_craft.html",val=res)
@app.route('/approve')
def approve():
    id=request.args.get('id')
    qry="update vendor set status='craft' where v_id=%s"
    iud(qry,id)
    return '''<script> 
        alert("Approved sucessful"),
        window.location='/approve_craft';
        </script>'''

@app.route('/block')
def block():
    id=request.args.get('id')
    qry="update vendor set status='blocked' where v_id=%s"
    iud(qry,id)
    return '''<script> 
        alert("Blocked sucessful"),
        window.location='/view_craft';
        </script>'''
@app.route('/unblock')
def unblock():
    id=request.args.get('id')
    qry="update vendor set status='craft' where v_id=%s"
    iud(qry,id)
    return '''<script> 
        alert("Bloked sucessful"),
        window.location='/view_craft';
        </script>'''

@app.route('/delete')
def delete():
    id=request.args.get('id')
    qry=" delete from vendor where v_id=%s "
    iud(qry,id)
    return '''<script> 
        alert("deleted sucessful"),
        window.location='/view_craft';
        </script>'''

@app.route('/reject')
def reject():
    id=request.args.get('id')
    qry="update vendor set status='rejected' where v_id=%s"
    iud(qry,id)
    return '''<script>
        alert("Rejected sucessfull"),
        window.location='/approve_craft';
        </script>'''


@app.route('/block_craft')
def block_craft():
    return render_template("admin/view_craft.html")

@app.route('/admin_salesreport')
def admin_salesreport():
    return render_template("admin/admin_sales_report.html")

@app.route('/view_craft')
def view_craft():
    qry="select * from vendor where status='craft' "
    res=selectall(qry)
    return render_template('admin/view_craft.html',val=res)
@app.route('/view_craft_product')
def view_craft_product():
    return render_template("admin/admin_view_craft_product.html")

@app.route('/admin_cust_order')
def admin_cust_order():
    return render_template("admin/admin_view_cust_order.html")

@app.route('/admin_non_cust_order')
def admin_non_cust_order():
    qry=" select * from `order` where status='pending' "
    res=selectall(qry)
    return render_template("admin/admin_view_non_cust_order.html",val=res)

@app.route('/admin_view_product')
def admin_view_product():
    qry = "select * from product where v_id=%s"
    val = session['lid']
    res = selectall2(qry, val)
    return render_template("admin/admin_view_product.html",val=res)

@app.route('/admin_view_unsought')
def admin_view_unsought():
    return render_template("admin/admin_view_unsought_product.html")

@app.route('/admin_feedback')
def admin_feedback():
    qry="select * from feedback"
    res=selectall(qry)
    return render_template("/admin/Feedback_rating.html",val=res)

@app.route('/reply')
def reply():
    return render_template("admin/Send_reply.html")

@app.route('/view_complaint')
def view_complaint():
    return render_template("admin/View_complaint.html")


################craft##############

@app.route('/craft_homepage')
def craft_homepage():
    return render_template("craft/Craft_home.html")

@app.route('/signup',methods=['post'])
def signup():
    fname=request.form['textfield']
    lname=request.form['textfield2']
    gender=request.form['radiobutton']
    hname=request.form['textfield3']
    place=request.form['textfield4']
    post=request.form['textfield5']
    pin=request.form['textfield6']
    district=request.form['district']
    idproof=request.files['file']
    phone=request.form['textfield8']
    email=request.form['textfield9']
    psw=request.form['textfield10']
    # file code
    flname=secure_filename(idproof.filename)
    idproof.save(os.path.join('static/id proof',flname))
    # qry="insert into login values(null,%s,%s,'craft')"
    # val=(email,psw)
    # iud(qry,val)

    qry="insert into vendor value (null,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,'pending')"
    val=(fname,lname,phone,hname,place,post,pin,district,flname,gender,email,psw)
    iud(qry,val)
    return '''<script> alert("Registeration sucessfull"); window.location='/'; </script>'''


@app.route('/craft_profile')
def craft_profile():
    qry="Select * from vendor where v_id=%s"
    val=session['lid']
    res=selectone(qry,val)
    return render_template("craft/view_craft_profile.html",val=res)

@app.route('/craft_update_profile',methods=['post'])
def craft_update_profile():
    fname = request.form['textfield']
    lname = request.form['textfield2']
    gender = request.form['radiobutton']
    hname = request.form['textfield3']
    place = request.form['textfield4']
    post = request.form['textfield5']
    pin = request.form['textfield6']
    district = request.form['district']
    phone = request.form['textfield8']
    email = request.form['textfield9']
    psw = request.form['textfield10']
    qry="update vendor set f_name=%s, l_name=%s, phone=%s, h_name=%s, place=%s,post=%s ,pin=%s,district=%s,gender=%s,username=%s,password=%s where v_id=%s"
    val=(fname,lname,phone,hname,place,post,pin,district,gender,email,psw,session['lid'])
    # print(val)
    res=iud(qry,val)
    return  '''<script>
        alert("Profile updated sucessfull"),
        window.location='/craft_profile';
        </script>'''



@app.route('/craft_add_product_code',methods=['post'])
def craft_add_product_code():
    p_name=request.form['textfield']
    catogery=request.form['select']
    occasion=request.form['select2']
    description=request.form['textarea']
    img=request.files['file']
    price=request.form['textfield3']
    qty=request.form['textfield4']
    v_id=session['lid']
    fname = secure_filename(img.filename)
    img.save(os.path.join('static/product', fname))
    qry="insert into product value(NULL ,%s,%s,%s,%s,%s,%s,%s,0,null ,%s)"
    val=(p_name,fname,catogery,occasion,description,qty,price,str(v_id))
    iud(qry,val)
    return '''<script> 
        alert("Added sucessfull"),
        window.location='/craft_view_product';
        </script>'''

@app.route('/craft_product_delete')
def craft_product_delete():
    id=request.args.get('id')
    qry="delete from product where p_id=%s"
    iud(qry,id)
    return '''<script>
    alert("Product deleted sucessful"),
    window.location="/craft_view_product";
    </script>'''


@app.route('/craft_edit_product')
def craft_edit_product():
    return render_template("craft/craft_edit_product.html")



@app.route('/craft_edit_product_code',methods=['post'])
def craft_edit_product_code():
    try:
        p_name=request.form['textfield']
        catogery=request.form['select']
        occasion=request.form['select2']
        description=request.form['textarea']
        # type=request.form['radiobutton']
        img=request.files['file']
        price=request.form['textfield3']
        qty=request.form['textfield4']
        v_id=session['lid']
        fname = secure_filename(img.filename)
        img.save(os.path.join('static/product', fname))
        qry="update product set p_name=%s ,fname=%s, category=%s, description=%s ,quantity=%s , price=%s,where p_id=%s"
        val=(p_name,fname,catogery,occasion,description,qty,price,session['pid'])
        iud(qry,val)
        return '''<script> 
            alert("Update sucessful"),
            window.location=''craft_view_product;
            </script>'''
    except Exception:

        p_name = request.form['textfield']
        catogery = request.form['select']
        occasion = request.form['select2']
        description = request.form['textarea']
        # type = request.form['radiobutton']
        price = request.form['textfield3']
        qty = request.form['textfield4']


        qry = "update product set p_name=%s ,occasion=%s, category=%s, description=%s, quantity=%s , price=%s where p_id=%s"
        val = (p_name, catogery, occasion, description, qty, price, type, session['pid'])
        iud(qry, val)
        return '''<script> 
                   alert("Update sucessful"),
                   window.location='/craft_view_product';
                   </script>'''

@app.route('/craft_adddiscount')
def craft_adddiscount():
    return render_template("craft/Craft_add_discount.html")

@app.route('/craft_add_product')
def craft_add_product():
    return render_template("craft/Craft_add_product.html")

@app.route('/craft_feedback')
def craft_feedback():
    return render_template("craft/Craft_Feedback_rating.html")

@app.route('/craft_reg')
def craft_reg():
    return render_template("craft/craft_makers_registration.html")

@app.route('/craft_salesreport')
def craft_salesreport():
    return render_template("craft/Craft_Sales report.html")

@app.route('/craft_order')
def craft_order():
    return render_template("craft/Craft_view_order.html")

@app.route('/craft_view_product')
def craft_view_product():
    qry="select * from product where v_id=%s"
    val=session['lid']

    res=selectall2(qry,val)
    return render_template("craft/Craft_view_product.html",val=res)

@app.route('/craft_unsought')
def craft_unsought():
    return render_template("craft/Craft_view_unsought_product.html")























##########
app.run(debug=True)